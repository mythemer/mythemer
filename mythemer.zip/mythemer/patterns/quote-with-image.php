<?php
/**
 * Title: Quote and image
 * Slug: mythemer/quote-with-image
 * Categories: theme, images
 * Block Types: core/image, core/quote
 *
 * @package mythemer
 * @since 1.0.0
 */

?>
<!-- wp:group {"layout":{"type":"flex","justifyContent":"space-between"}} -->
<div class="wp-block-group">
	<!-- wp:quote -->
	<blockquote class="wp-block-quote"><!-- wp:paragraph -->
	<p></p>
	<!-- /wp:paragraph --></blockquote>
	<!-- /wp:quote -->
	<!-- wp:image {"width":200,"height":200,"sizeSlug":"full","linkDestination":"none"} -->
	<figure class="wp-block-image size-full is-resized"><img alt="" /></figure>
	<!-- /wp:image -->
</div>
<!-- /wp:group -->
